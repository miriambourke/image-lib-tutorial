/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const newOnCreatePicture = /* GraphQL */ `
  subscription NewOnCreatePicture {
    newOnCreatePicture {
      id
      name
      owner
      labels
      file {
        bucket
        region
        key
      }
      createdAt
      updatedAt
    }
  }
`;
export const newOnUpdatePicture = /* GraphQL */ `
  subscription NewOnUpdatePicture {
    newOnUpdatePicture {
      id
      name
      owner
      labels
      file {
        bucket
        region
        key
      }
      createdAt
      updatedAt
    }
  }
`;
export const newOnDeletePicture = /* GraphQL */ `
  subscription NewOnDeletePicture {
    newOnDeletePicture {
      id
      name
      owner
      labels
      file {
        bucket
        region
        key
      }
      createdAt
      updatedAt
    }
  }
`;
export const onCreatePicture = /* GraphQL */ `
  subscription OnCreatePicture {
    onCreatePicture {
      id
      name
      owner
      labels
      file {
        bucket
        region
        key
      }
      createdAt
      updatedAt
    }
  }
`;
export const onUpdatePicture = /* GraphQL */ `
  subscription OnUpdatePicture {
    onUpdatePicture {
      id
      name
      owner
      labels
      file {
        bucket
        region
        key
      }
      createdAt
      updatedAt
    }
  }
`;
export const onDeletePicture = /* GraphQL */ `
  subscription OnDeletePicture {
    onDeletePicture {
      id
      name
      owner
      labels
      file {
        bucket
        region
        key
      }
      createdAt
      updatedAt
    }
  }
`;
